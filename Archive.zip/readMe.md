# [UA] Офіційний сайт благодійної організації «ДОПОМОГА ПОСТРАЖДАЛИМ ДІТЯМ З УКРАЇНИ»

Головними цілями даної організації є допомога дітям, котрі постраждали від російської агресії (з маленької букви не спроста, не заслуговують вони на повагу).

# [ENG] Official website of the charity organization «HELP FOR AFFECTED CHILDREN FROM UKRAINE»

The main goals of this organization are to help children who suffered from russian aggression (it's not just a small letter, they don't deserve respect).

URL => https://volunteer-help.org.ua/

Stack: HTML5, SCSS, native JS, SwiperJS
